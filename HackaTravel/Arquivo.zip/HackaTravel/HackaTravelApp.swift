//
//  HackaTravelApp.swift
//  HackaTravel
//
//  Created by Turma02-3 on 25/06/24.
//

import SwiftUI

@main
struct HackaTravelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
