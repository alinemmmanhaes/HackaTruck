//
//  ContentView.swift
//  HackaTravel
//
//  Created by Turma02-1 on 26/06/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
            NavigationLink(destination: ChatView()){
                Text("Vou testar")
            }
        }
    }
}

#Preview {
    ContentView()
}
