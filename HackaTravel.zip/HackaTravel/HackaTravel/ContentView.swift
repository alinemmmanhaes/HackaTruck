//
//  ContentView.swift
//  HackaTravel
//
//  Created by Turma02-1 on 26/06/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
            NavigationLink(destination: ChatView(tipo: 3, nome: "Aline", foto: "https://blog.unyleya.edu.br/wp-content/uploads/2017/12/saiba-como-a-educacao-ajuda-voce-a-ser-uma-pessoa-melhor.jpeg")){
                Text("Vou testar")
            }
        }
    }
}

#Preview {
    ContentView()
}
