//
//  HackaTravelApp.swift
//  HackaTravel
//
//  Created by Turma02-1 on 26/06/24.
//

import SwiftUI

@main
struct HackaTravelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
